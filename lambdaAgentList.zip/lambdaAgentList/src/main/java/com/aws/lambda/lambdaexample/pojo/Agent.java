package com.aws.lambda.lambdaexample.pojo;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="Agent")
public class Agent {
	
	@DynamoDBHashKey
	private String agent_id;

	public String getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(String agent_id) {
		this.agent_id = agent_id;
	}

	public Agent(String agent_id) {
		super();
		this.agent_id = agent_id;
	}
	
	public Agent() {
		super();
	
	}
}
