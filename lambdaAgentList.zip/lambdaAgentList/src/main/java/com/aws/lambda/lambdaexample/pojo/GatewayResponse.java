package com.aws.lambda.lambdaexample.pojo;

import java.util.List;
import java.util.Map;

public class GatewayResponse {
	
	private List<Agent> listAgents;
	private Integer statusCode;
	private Map<String,String> headers;
	private boolean isBase64Encoded;
	public List<Agent> getListAgents() {
		return listAgents;
	}
	public void setListAgents(List<Agent> listAgents) {
		this.listAgents = listAgents;
	}
	public Integer getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
	public boolean isBase64Encoded() {
		return isBase64Encoded;
	}
	public void setBase64Encoded(boolean isBase64Encoded) {
		this.isBase64Encoded = isBase64Encoded;
	}
	public GatewayResponse(List<Agent> listAgents, Integer statusCode, Map<String, String> headers,
			boolean isBase64Encoded) {
		super();
		this.listAgents = listAgents;
		this.statusCode = statusCode;
		this.headers = headers;
		this.isBase64Encoded = isBase64Encoded;
	}
	
	public GatewayResponse() {
		super();
		
	}
	
	
	
}
