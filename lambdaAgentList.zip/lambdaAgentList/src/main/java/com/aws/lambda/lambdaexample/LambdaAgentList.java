package com.aws.lambda.lambdaexample;

import java.util.Collections;
import java.util.List;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.aws.lambda.lambdaexample.pojo.GatewayResponse;
import com.aws.lambda.lambdaexample.pojo.Agent;
import com.aws.lambda.lambdaexample.request.AgentRequest;

public class LambdaAgentList implements RequestHandler<AgentRequest, GatewayResponse>{

	@Override
	public GatewayResponse handleRequest(AgentRequest request, Context context) {
		
		GatewayResponse response = new GatewayResponse();
		response.setBase64Encoded(false);
		response.setStatusCode(200);
		try {
			System.out.println("handle request initiated.");
			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.defaultClient();
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
			DynamoDBMapper mapper = new DynamoDBMapper(client);
			List<Agent> scanResult = mapper.scan(Agent.class, scanExpression);
			response.setHeaders(Collections.singletonMap("author-name", "Dipin"));
			response.setListAgents(scanResult);
		}catch(Exception e) {
			response.setStatusCode(500);
			System.out.println("Exception occured:"+e);
			e.printStackTrace();
		}
		return response;
		
	}
}
