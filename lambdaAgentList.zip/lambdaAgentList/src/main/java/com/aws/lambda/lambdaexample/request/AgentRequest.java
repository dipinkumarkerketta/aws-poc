package com.aws.lambda.lambdaexample.request;

public class AgentRequest {

	private String httpMethod;

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}
	
	
	
}
