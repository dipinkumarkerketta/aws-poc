//This is Main Java Script File, All Script are written here only

function validateAndSubmitSSOPage()
{
	var ssoid = document.getElementById("ssoID").value;
	var location = document.getElementById("location").value;
	if (ssoid.length == 0)
	{
		alert("Please Enter SSO ID");
	} else if (location.length == 0)
	{
		alert("Please enter Password");
	}
	else 
	{
		checkLogin(ssoid, location);
	}
}

function validateAndSubmitPPTUpload(ssoid) {

	var pollid = document.getElementById("pollId").value;
	var uploadfile = document.getElementById("uploadFile");
	var uploadForm = document.getElementById("pollForm");

	var ext = "";

	if (pollid == 0) {
		alert("Please Select Poll ID");
		return false;
	} else if (uploadfile.value.length == 0) {
		alert("Please enter PPTX to Upload");
		return false;
	} else {

		ext = uploadfile.value.substring(uploadfile.value.lastIndexOf(".") + 1);
		ext = ext.toUpperCase();
		// "PPT"!=ext &&
		if ("PPTX" != ext) {
			alert("Only pptx format is allowed");
			uploadfile.value = '';
			return false;
		}
	}
	uploadForm.action = "./uploadPPTMain?ssoID=" + ssoid;
	document.getElementById("uploadBtn").disabled = true;
	uploadForm.submit();

}



function validateAndSubmitPPTMapping() {

	var slideArr = new Array();
	var questionArr = new Array();

	var uploadMapping = document.getElementById("mappingForm");
	slideArr = document.getElementsByName("slideArr");
	questionArr = document.getElementsByName("questionArr");

	var slideObj = null;
	var qstObj = null;
	var forResult = false;
	for (var q = 0; q < slideArr.length; q++) {
		try {
			forResult = false;
			slideObj = slideArr[q];
			qstObj = questionArr[q];
			if (slideObj.value == '0') {
				alert("Please select Slide");
				slideObj.focus();
				forResult = true;
				break;
			} else if (qstObj.value == '0') {
				alert("Please select Question");
				qstObj.focus();
				forResult = true;
				break;
			}

		} catch (e) {
			alert("Some problem occurred, please try again");
			return false;
		}
	}

	if (forResult) {
		return false;
	}

	uploadMapping.action = "./pptMapping";
	document.getElementById("mappingBtn").disabled = true;
	uploadMapping.submit();

}

function checkLogin(ssoid, location) {

	$.ajax({
		type : "GET",
		contentType : "application/json",
		url : "checkLogin",
		data : {
			"ssoId" : ssoid,
			"psd" : location,
			"t" : new Date().getTime()
		},
		dataType : 'text',
		timeout : 100000,
		success : function(status) {
			var build = '';
			if (status != null && status != undefined) {
				if ("200" == status) {
					// window.location.href ="./showSurvey?ssoID="+ssoid;
					window.location.href = "./showHome?ssoID=" + ssoid;
				} else {
					alert("SSO ID or password are incorrect");
					document.getElementById("ssoID").focus;
					return false;
				}

			}
		},
		error : function(e) {
			alert("ERROR: ", e);
			alert(e);
		},
		done : function(e) {
			alert("DONE");
		}
	});

}

function validateAndSubmitPOLL() {

	var Poll = document.getElementById("pollId").value;

	var Pin = document.getElementById("action").value;

	if (Poll.length == 0) {
		alert("Please Select Poll");
	} else if (Pin.length == 0) {
		alert("Please enter Pin");
	} else {
		var PollArr = Poll.split("|||");

		var actualPin = PollArr[0];
		var pollid = PollArr[1];

		if (actualPin == Pin) {
			document.getElementById("pollForm").action = "./adminActive?pollId="
					+ pollid;
			document.getElementById("pollForm").submit();
		} else {
			alert("Please enter valid PIN");
			document.getElementById("action").focus;
			return false;
		}
	}

}
function showSurveyPage(questionId) {
	// alert(questionId);
	document.getElementById("questionId").value = questionId;
	// document.getElementById("ssoId").value = ssoid;
	document.getElementById("selectQuestionForm").action = "/dmm/showSurveyQuestion.do";
	document.getElementById("selectQuestionForm").submit();
}

function backSurveyPage(sso) {
	document.getElementById("surveyForm").action = "/dmm/showSurvey.do?ssoId="
			+ sso;
	document.getElementById("surveyForm").method = "GET";
	document.getElementById("surveyForm").submit();
}

function submitSurvey() {

	if (document.getElementById("question_response_txt") != null) {
		var userResponse = document.getElementById("question_response_txt").value;

		if (userResponse.length == 0) {
			alert("Please Enter Your Response");
		} else {
			document.getElementById("surveyForm").action = "/dmm/submitSurveyQuestion.do";
			document.getElementById("surveyForm").submit();
		}
	} else {
		var radioButton = document.getElementsByName("radio");
		var radioChecked = false;
		for (var i = 0; i < radioButton.length; i++) {
			if (radioButton[i].checked) {
				radioChecked = true;
				break;
			}
		}

		if (radioChecked) {
			document.getElementById("surveyForm").action = "/dmm/submitSurveyQuestion.do";
			document.getElementById("surveyForm").submit();
		} else {
			alert("Please Select An Option");
		}
	}

}

function submitSurveyTest() {

	if (document.getElementById("question_response_txt") != null) {
		var userResponse = document.getElementById("question_response_txt").value;

		if (userResponse.length == 0) {
			alert("Please Enter Your Response");
		} else {
			$("#modelTrigger").click();
			document.getElementById("surveyForm").action = "./submitUserTest.do";
			document.getElementById("surveyForm").submit();
		}
	} else {
		var radioButton = document.getElementsByName("radio");
		var radioChecked = false;
		for (var i = 0; i < radioButton.length; i++) {
			if (radioButton[i].checked) {
				radioChecked = true;
				break;
			}
		}

		if (radioChecked) {
			$("#modelTrigger").click();
			document.getElementById("surveyForm").action = "./submitUserTest.do";
			document.getElementById("surveyForm").submit();
		} else {
			if (document.getElementById("slideValue") != null
					|| document.getElementById("gridValue") != null) {
				$("#modelTrigger").click();
				document.getElementById("surveyForm").action = "./submitUserTest.do";
				document.getElementById("surveyForm").submit();
			} else {
				alert("Please Select An Option");
			}
		}
	}

}
function submitSurveyTestNext() {

	if (document.getElementById("question_response_txt") != null) {
		var userResponse = document.getElementById("question_response_txt").value;

		if (userResponse.length == 0) {
			alert("Please Enter Your Response");
		} else {
			$("#modelTrigger").click();
			document.getElementById("surveyForm").action = "./submitSurveyQuestionTest.do";
			document.getElementById("surveyForm").submit();
		}
	} else {
		var radioButton = document.getElementsByName("radio");
		var radioChecked = false;
		for (var i = 0; i < radioButton.length; i++) {
			if (radioButton[i].checked) {
				radioChecked = true;
				break;
			}
		}

		if (radioChecked) {
			$("#modelTrigger").click();
			document.getElementById("surveyForm").action = "./submitSurveyQuestionTest.do";
			document.getElementById("surveyForm").submit();
		} else {
			if (document.getElementById("slideValue") != null
					|| document.getElementById("gridValue") != null) {
				$("#modelTrigger").click();
				document.getElementById("surveyForm").action = "./submitSurveyQuestionTest.do";
				document.getElementById("surveyForm").submit();
			} else {
				alert("Please Select An Option");
			}
		}
	}

}

function checkSpecialChar(e) {
	var k;
	document.all ? k = e.keyCode : k = e.which;
	// alert(k);
	return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32
			|| (k >= 48 && k <= 57) || k == 44 || k == 46 || k == 40 || k == 41
			|| k == 45 || k == 13);
}

function maxDesc(obj, max) {
	var temp = obj.value;
	var lenngthL = temp.length;
	if (parseInt(lenngthL) > max) {
		obj.value = temp.substring(0, max);
	}
}

function getHttpRequestObject() {
	var xmlhttp;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	return xmlhttp;
}

function cleanRadio() {
	var radioButton = document.getElementsByName("radio");

	for (var i = 0; i < radioButton.length; i++) {
		radioButton[i].checked = false;
	}

	var objAgent = navigator.userAgent;
	if (((objOffsetVersion = objAgent.indexOf("MSIE 8")) != -1)
			|| ((objOffsetVersion = objAgent.indexOf("MSIE 7")) != -1)
			|| ((objOffsetVersion = objAgent.indexOf("MSIE 6")) != -1)) {
		// window.location = "./redirectIEIssue.jspx";
	}
}

function setRadio(num) {
	document.getElementById("radio" + num).checked = true;
}

function submitQuestionAdmin() {
	document.getElementById("questionAdminForm").action = "./submitQuestionAdmin.do";
	document.getElementById("questionAdminForm").submit();
}

function checkQstAjax() {
	var qstIdVal = $("#questionId").val();
	alert(qstIdVal);
	$
			.ajax({
				type : "GET",
				contentType : "application/json",
				url : "./checkQstAjax",
				data : {
					"qstId" : qstIdVal,
					"t" : new Date().getTime()
				},
				dataType : 'text',
				timeout : 100000,
				success : function(status) {
					var build = '';
					if (status != null && status != undefined) {
						if ("1" == status) {
							// do nothing
							build = "same Question";
						} else if ("2" == status) {
							build = "No Question Assigned";
							window.location.href = "./NoItemsAssignedAction.do";
						} else if ("3" == status) {
							build = "Question Assigned";
							build = "3";
							alert("ok");
							$("#changeZone").innerHTML = '<h2 id="qusIdShow">Q:Question will come here</h2> <li id="opt1"><input type="radio" name="radio" class="radio-btn" id="radioOptn1" value="1"><label for="radioOptn1"><span id="optnTxt1">${surveyQuestion.option1}</span></label></li><li id="opt2"><input type="radio" name="radio" class="radio-btn" id="radioOptn2" value="2" ><label for="radioOptn2"><span id="optnTxt2">${surveyQuestion.option2}</span></label></li><li id="opt3" style="display:none;"><input type="radio" name="radio" class="radio-btn" id="radioOptn3" value="3" ><label for="radioOptn3" id="radioOptnTxt3"><span id="optnTxt3">${surveyQuestion.option3}</span></label></li><li id="opt4" style="display:none;">                            <input type="radio" name="radio" class="radio-btn" id="radioOptn4" value="4" ><label for="radioOptn4" id="radioOptnTxt4"><span id="optnTxt4">${surveyQuestion.option4}</span></label></li><li id="opt5" style="display:none;"><input type="radio" name="radio" class="radio-btn" id="radioOptn5" value="5" ><label for="radioOptn5" id="radioOptnTxt5"><span id="optnTxt5">${surveyQuestion.option5}</span></label></li><li id="opt6" style="display:none;"><input type="radio" name="radio" class="radio-btn" id="radioOptn6" value="6" ><label for="radioOptn6" id="radioOptnTxt6"><span id="optnTxt6">${surveyQuestion.option6}</span></label></li>';
						} else {
							build = "else Error";
							build = "4";
						}

					}
				},
				error : function(e) {
					alert("ERROR: ", e);
					alert(e);
				},
				done : function(e) {
					alert("DONE");
				}
			});

}
function downloadfile(downloadPath) {

	document.downloadPPtForm.fileCompletePath.value = downloadPath;
	document.downloadPPtForm.submit();
}

function getSelOptn(index, optnArraylength) {
	var checkCurrentDomClass = false;
	if (document.getElementById("selOptn" + index).classList
			.contains("selected")) {
		checkCurrentDomClass = true;
	}
	for (var i = 0; i < optnArraylength; i++) {
		$("#selOptn" + i).removeClass("selected");
	}
	if (!checkCurrentDomClass) {
		$('#selOptn' + index).addClass('selected');

		document.getElementById("optVal").value = document
				.getElementById("selOptn" + index).innerHTML;
		document.getElementById("optNo").value = document
				.getElementById("selOptn" + index).value;
	}
}

/*function submitAnswerSurvey(checkSbmitData, optnArraylength) {

	
	var userAnsForm = document.userAnsForm;
	var submittedAnswer;
	for (var i = 0; i < optnArraylength; i++) {
		if (document.getElementById("selOptn" + i).classList
				.contains("selected")) {
			// checkCurrentDomClass=true;
			submittedAnswer = document.getElementById("selOptn" + i).innerHTML;
		}
	}
	
	var answerSelected = false;
	var submitOptnData;
	var checkSubmitType = "";
	for (var i = 0; i < optnArraylength; i++) {
		if (document.getElementById('selOptn' + i).classList
				.contains("selected")) {
			answerSelected = true;
		}
	}
	
	if (checkSbmitData != undefined && checkSbmitData != "undefined"
			&& checkSbmitData != null && checkSbmitData != "null") {
		submitOptnData = checkSbmitData;
		checkSubmitType = "Auto";
	} else {
		checkSubmitType = "Manual";
		submitOptnData = $("#optVal").val() + "||$||" + $("#optNo").val();

	}
	
	if (!answerSelected && checkSubmitType != "Auto") {
		alert("Please select your answer first!");
		return false;
	}
	
	// userQusPageIntrval()
	if (checkSbmitData != null) {
		userAnsForm.optVal.value = checkSbmitData;
	}
	userAnsForm.action = "./submitUserAns";
	document.getElementById("ansBtn").disabled = true;
	userAnsForm.submit();
	
}*/



function submitAnswerNextSurvey(checkSbmitData, optnArraylength) {

	
	var userAnsForm = document.userAnsForm;
	var submittedAnswer;
	for (var i = 0; i < optnArraylength; i++) {
		if (document.getElementById("selOptn" + i).classList
				.contains("selected")) {
			// checkCurrentDomClass=true;
			submittedAnswer = document.getElementById("selOptn" + i).innerHTML;
		}
	}
	
	var answerSelected = false;
	var submitOptnData;
	var checkSubmitType = "";
	for (var i = 0; i < optnArraylength; i++) {
		if (document.getElementById('selOptn' + i).classList
				.contains("selected")) {
			answerSelected = true;
		}
	}
	
	if (checkSbmitData != undefined && checkSbmitData != "undefined"
			&& checkSbmitData != null && checkSbmitData != "null") {
		submitOptnData = checkSbmitData;
		checkSubmitType = "Auto";
	} else {
		checkSubmitType = "Manual";
		submitOptnData = $("#optVal").val() + "||$||" + $("#optNo").val();
	}
	
	if (!answerSelected && checkSubmitType != "Auto") {
		alert("Please select your answer first!");
		return false;
	}
	
	// userQusPageIntrval()
	if (checkSbmitData != null) {
		userAnsForm.optVal.value = checkSbmitData;
	}
	userAnsForm.action = "./submitnextQst";
	document.getElementById("ansBtn").disabled = true;
	userAnsForm.submit();
	
}
function userQusPageIntrval() {
	try {
		if (userQusIntrval != undefined) {
			clearInterval(userQusIntrval);
		}
	} catch (e) {
		console.log(e);
	}
}

function submitAnswer(checkSbmitData, optnArraylength) {

	
	var userAnsForm = document.userAnsForm;
	var submittedAnswer;
	for (var i = 0; i < optnArraylength; i++) {
		if (document.getElementById("selOptn" + i).classList
				.contains("selected")) {
			// checkCurrentDomClass=true;
			submittedAnswer = document.getElementById("selOptn" + i).innerHTML;
		}
	}
	
	var answerSelected = false;
	var submitOptnData;
	var checkSubmitType = "";
	for (var i = 0; i < optnArraylength; i++) {
		if (document.getElementById('selOptn' + i).classList
				.contains("selected")) {
			answerSelected = true;
		}
	}
	
	if (checkSbmitData != undefined && checkSbmitData != "undefined"
			&& checkSbmitData != null && checkSbmitData != "null") {
		submitOptnData = checkSbmitData;
		checkSubmitType = "Auto";
	} else {
		checkSubmitType = "Manual";
		submitOptnData = $("#optVal").val() + "||$||" + $("#optNo").val();

	}
	
	if (!answerSelected && checkSubmitType != "Auto") {
		alert("Please select your answer first!");
		return false;
	}
	
	// userQusPageIntrval()
	if (checkSbmitData != null) {
		userAnsForm.optVal.value = checkSbmitData;
	}
	userAnsForm.action = "./submitUserAns";
	document.getElementById("ansBtn").disabled = true;
	userAnsForm.submit();
	
}
function validateAndSubmitUserCredential()
{
	var userSsoId = document.getElementById("ssoId");
	var userSsoPswd = document.getElementById("pswd");
	var formname = document.getElementById("userLoginForm");
	if (userSsoId.value == 0) {
		alert("Please Enter SSOID");
		userSsoId.focus();
		return false;
	} 
	if (userSsoPswd.value == 0)
	{
		alert("Please Enter Password");
		userSsoPswd.focus();
		return false;
	} 
	formname.action = "./checkUserCredential";
	document.getElementById("userLoginbtn").disabled = true;
	formname.submit();
}
function validateAndSubmitUserPin() {

	var userPinstr = document.getElementById("userPin");
	var formname = document.getElementById("userLoginForm");

	var reg = /^\d+$/;

	if (userPinstr.value == 0) {
		alert("Please Enter Pin");
		userPinstr.focus();
		return false;
	} else if (!reg.test(userPinstr.value)) {
		alert("Please enter valid Pin");
		userPinstr.value = "";
		userPinstr.focus();
		return false;
	}
	
	formname.action = "./checkUserPin";
	document.getElementById("userLoginbtn").disabled = true;
	formname.submit();
}

function logoutshow()
{
    $("#togglehide").toggle(170);
}

function logouthide()
{
    $("#togglehide").hide();
}
function logoutQusPage()
{
	window.location.href="./";
}

function submitAnswerFreeText()
{
	var freetextVal=$('#freeText').val();
	if(freetextVal.length>500) 
	{
	alert("The text you have submit should less than 500 chracter");	
	return false;
	}
	
	if (freetextVal != undefined && freetextVal != "undefined"
		&& freetextVal != null && freetextVal != "null" && freetextVal!='' && freetextVal!=" " && freetextVal.length<501) {
		userAnsForm.optVal.value =freetextVal;
	}
	else
	{
	 alert("Please enter your answer first!");
	 return false;
	}
	userAnsForm.action = "./submitUserAns";
	document.getElementById("ansBtn").disabled = true;
	userAnsForm.submit();
}

function submitAnswerFreeTextSurvey()
{
	var freetextVal=$('#freeText').val();
	if(freetextVal.length>500) 
	{
	alert("The text you have submit should less than 500 chracter");	
	return false;
	}
	
	if (freetextVal != undefined && freetextVal != "undefined"
		&& freetextVal != null && freetextVal != "null" && freetextVal!='' && freetextVal!=" " && freetextVal.length<501) {
		userAnsForm.optVal.value =freetextVal;
	}
	else
	{
	 alert("Please enter your answer first!");
	 return false;
	}
	userAnsForm.action = "./submitnextQst";
	document.getElementById("ansBtn").disabled = true;
	userAnsForm.submit();
}




